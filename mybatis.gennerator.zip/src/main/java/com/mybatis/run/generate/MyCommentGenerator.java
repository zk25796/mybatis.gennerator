package com.mybatis.run.generate;

import java.util.Properties;

import org.mybatis.generator.api.CommentGenerator;
import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.CompilationUnit;
import org.mybatis.generator.api.dom.java.Field;
import org.mybatis.generator.api.dom.java.InnerClass;
import org.mybatis.generator.api.dom.java.InnerEnum;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.java.TopLevelClass;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.internal.DefaultCommentGenerator;
import org.mybatis.generator.internal.util.StringUtility;

public class MyCommentGenerator extends DefaultCommentGenerator {

	@Override
	public void addFieldComment(Field field, IntrospectedTable introspectedTable,
			IntrospectedColumn introspectedColumn) {

        field.addJavaDocLine("/**"); //$NON-NLS-1$
        String remarks = introspectedColumn.getRemarks();
        if ( StringUtility.stringHasValue(remarks)) {
            field.addJavaDocLine(" * remark:");
            String[] remarkLines = remarks.split(System.getProperty("line.separator"));  //$NON-NLS-1$
            for (String remarkLine : remarkLines) {
                field.addJavaDocLine(" *   " + remarkLine);  //$NON-NLS-1$
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(" *  corresponds  database column "); //$NON-NLS-1$
        sb.append(introspectedColumn.getActualColumnName());
        field.addJavaDocLine(sb.toString());

        //addJavadocTag(field, false);

        field.addJavaDocLine(" */"); //$NON-NLS-1$
    
	}

	 @Override
	    public void addModelClassComment(TopLevelClass topLevelClass,
	            IntrospectedTable introspectedTable) {

	        StringBuilder sb = new StringBuilder();

	        topLevelClass.addJavaDocLine("/**"); //$NON-NLS-1$

	        String remarks = introspectedTable.getRemarks();
	        if ( StringUtility.stringHasValue(remarks)) {
	            topLevelClass.addJavaDocLine(" * Entity Remarks:");
	            String[] remarkLines = remarks.split(System.getProperty("line.separator"));  //$NON-NLS-1$
	            for (String remarkLine : remarkLines) {
	                topLevelClass.addJavaDocLine(" *   " + remarkLine);  //$NON-NLS-1$
	            }
	        }
	        sb.append(" * This class corresponds to the database table "); //$NON-NLS-1$
	        sb.append(introspectedTable.getFullyQualifiedTable());
	        topLevelClass.addJavaDocLine(sb.toString());
	        topLevelClass.addJavaDocLine(" */"); //$NON-NLS-1$
	    }
	
	
}
