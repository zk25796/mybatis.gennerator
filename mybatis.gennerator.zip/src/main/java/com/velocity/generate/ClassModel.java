package com.velocity.generate;

public class ClassModel {
	public ClassModel(String className, String remark) {
		super();
		this.modelName = className;
		this.remark = remark;
	}
	String modelName;
	String remark;
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
}
