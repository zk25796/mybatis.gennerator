package com.velocity.generate;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.apache.velocity.texen.util.FileUtil;
	
public class CodeGenerate {
public static void fileCopy(File src,File target){
		try {
			String name=src.getName().substring(0,src.getName().indexOf("."));
			BufferedReader fileReader=new BufferedReader(new FileReader(src));
			BufferedWriter  fileWriter=new BufferedWriter(new FileWriter(target));
			String line=null;
			while((line=fileReader.readLine())!=null){
				if(line.contains("public class")){
					line=line.replace(name, name+"Model");
				}
				if(line.contains("package ")){
					line =line.replace("entity", "model");
				}
				fileWriter.write(line+"\n");
			}
			fileWriter.flush();
			fileWriter.close();
			fileReader.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		/*生成model代码*/
		File  dir=new File("src/main/java/com/wuage/order/entity/");
		File[] listFiles = dir.listFiles();
		String modelPath="src/main/java/com/wuage/order/model/";
		FileUtil.mkdir(modelPath);
		for (File file : listFiles) {
			if(!file.getName().contains("Example")){
				File newFile=new File(modelPath+file.getName().replace(".java", "Model.java"));
				CodeGenerate.fileCopy(file,newFile);
			}
		}
		String path = "src/main/java/com/wuage/order/service/";
		FileUtil.mkdir(path);
		FileUtil.mkdir(path + "impl");
		VelocityEngine ve = new VelocityEngine();
		ve.setProperty("input.encoding", "UTF8");
		ve.setProperty("output.encoding", "UTF8");

		ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
		ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
		ve.init();
		Template tservice = ve.getTemplate("service.vm");
		Template tImpl = ve.getTemplate("serviceImpl.vm");
		VelocityContext ctx = new VelocityContext();
		ClassModel[] pojos = { new ClassModel("Order", "订单操作服务"), new ClassModel("OrderOffer", "商品明细操作服务"),
				new ClassModel("Carrier", "承运商服务"), new ClassModel("DelayReceive", "延迟收货服务"),
				new ClassModel("Driver", "司机表服务"), new ClassModel("LogisticsAddress", "收货地址操作服务"),
				new ClassModel("Logistics", "物流信息服务"), new ClassModel("Attachment", "附件操作服务"),
				new ClassModel("OrderInvoice", "发货单服务"), new ClassModel("OrderInvoiceDetail", "发货单明细服务"),
				new ClassModel("OrderOperationLog", "订单日志服务"), new ClassModel("OrderStage", "分阶段表服务"), };

		Arrays.asList(pojos).stream().forEach(pojo -> {
			ctx.put("pojo", pojo.getModelName());
			ctx.put("remark", pojo.getRemark());
			ctx.put("date", DateFormatUtils.format(new Date(), "yyyy年MM月dd日 HH时:mm分"));
			try {
				/* 服务接口 */
				File ser = new File(path + pojo.getModelName() + "Service.java");
				FileWriter fileWriter = new FileWriter(ser);
				tservice.merge(ctx, fileWriter);
				fileWriter.flush();
				fileWriter.close();
				/* 服务实现类 */
				File imp = new File(path + "impl/" + pojo.getModelName() + "ServiceImpl.java");
				fileWriter = new FileWriter(imp);
				tImpl.merge(ctx, fileWriter);
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

		System.out.println();
	}
}
