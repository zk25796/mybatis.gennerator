package com.wuage.order.model;

import java.util.Date;

/**
 * Entity Remarks:
 *   订单附件表
 * This class corresponds to the database table tc_attachment
 */
public class AttachmentModel {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   来源业务标识
     *  corresponds  database column source_id
     */
    private String sourceId;

    /**
     * remark:
     *   来源类型
     *  corresponds  database column source_type
     */
    private String sourceType;

    /**
     * remark:
     *   图片服务器地址
     *  corresponds  database column url
     */
    private String url;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId == null ? null : sourceId.trim();
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType == null ? null : sourceType.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
