package com.wuage.order.model;

import java.util.Date;

/**
 * Entity Remarks:
 *   订单操作日志表
 * This class corresponds to the database table tc_order_operation_log
 */
public class OrderOperationLogModel {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   操作人
     *  corresponds  database column operator
     */
    private String operator;

    /**
     * remark:
     *   操作编码
     *  corresponds  database column operation_code
     */
    private String operationCode;

    /**
     * remark:
     *   状态
     *  corresponds  database column status
     */
    private String status;

    /**
     * remark:
     *   操作时间
     *  corresponds  database column operation_time
     */
    private Date operationTime;

    /**
     * remark:
     *   描述
     *  corresponds  database column remark
     */
    private String remark;

    /**
     * remark:
     *   操作内容结构化数据
     *  corresponds  database column content
     */
    private String content;

    /**
     * remark:
     *   订单id
     *  corresponds  database column order_id
     */
    private Long orderId;

    /**
     * remark:
     *   业务id
     *  corresponds  database column biz_id
     */
    private Long bizId;

    /**
     * remark:
     *   阶段id
     *  corresponds  database column stage_id
     */
    private Long stageId;

    /**
     * remark:
     *   业务类型
     *  corresponds  database column biz_type
     */
    private String bizType;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public String getOperationCode() {
        return operationCode;
    }

    public void setOperationCode(String operationCode) {
        this.operationCode = operationCode == null ? null : operationCode.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getBizId() {
        return bizId;
    }

    public void setBizId(Long bizId) {
        this.bizId = bizId;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public String getBizType() {
        return bizType;
    }

    public void setBizType(String bizType) {
        this.bizType = bizType == null ? null : bizType.trim();
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
