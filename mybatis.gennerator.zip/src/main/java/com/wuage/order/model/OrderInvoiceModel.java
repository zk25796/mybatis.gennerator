package com.wuage.order.model;

import java.util.Date;

/**
 * Entity Remarks:
 *   发货单
 * This class corresponds to the database table tcr_order_invoice
 */
public class OrderInvoiceModel {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   出库单号
     *  corresponds  database column inventory_code
     */
    private String inventoryCode;

    /**
     * remark:
     *   发货人
     *  corresponds  database column sender
     */
    private String sender;

    /**
     * remark:
     *   运单号
     *  corresponds  database column waybill_no
     */
    private String waybillNo;

    /**
     * remark:
     *   收货人信息
     *  corresponds  database column receiver
     */
    private String receiver;

    /**
     * remark:
     *   发货单状态
     *  corresponds  database column status
     */
    private Integer status;

    /**
     * remark:
     *   订单id
     *  corresponds  database column order_id
     */
    private Long orderId;

    /**
     * remark:
     *   阶段id
     *  corresponds  database column stage_id
     */
    private Long stageId;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getInventoryCode() {
        return inventoryCode;
    }

    public void setInventoryCode(String inventoryCode) {
        this.inventoryCode = inventoryCode == null ? null : inventoryCode.trim();
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender == null ? null : sender.trim();
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo == null ? null : waybillNo.trim();
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver == null ? null : receiver.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
