package com.wuage.order.model;

import java.util.Date;

/**
 * Entity Remarks:
 *   用来记录多次延迟收货记录的信息
 * This class corresponds to the database table tc_delay_receive
 */
public class DelayReceiveModel {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   阶段id
     *  corresponds  database column stage_id
     */
    private Long stageId;

    /**
     * remark:
     *   延期时间
     *  corresponds  database column delay_time
     */
    private Date delayTime;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public Date getDelayTime() {
        return delayTime;
    }

    public void setDelayTime(Date delayTime) {
        this.delayTime = delayTime;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
