package com.wuage.order.model;

import java.util.Date;

/**
 * Entity Remarks:
 *   承运商
 * This class corresponds to the database table tc_carrier
 */
public class CarrierModel {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   承运商名称
     *  corresponds  database column company_name
     */
    private String companyName;

    /**
     * remark:
     *   承运商类型
     *  corresponds  database column company_type
     */
    private String companyType;

    /**
     * remark:
     *   发货单id
     *  corresponds  database column invoice_id
     */
    private Long invoiceId;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType == null ? null : companyType.trim();
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
