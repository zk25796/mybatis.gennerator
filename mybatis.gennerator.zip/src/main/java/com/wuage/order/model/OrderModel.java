package com.wuage.order.model;

import java.util.Date;

/**
 * Entity Remarks:
 *   订单表
 * This class corresponds to the database table tc_order
 */
public class OrderModel {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   订单号
     *  corresponds  database column order_no
     */
    private String orderNo;

    /**
     * remark:
     *   卖家id
     *  corresponds  database column seller_user_id
     */
    private String sellerUserId;

    /**
     * remark:
     *   卖家业务联系电话
     *  corresponds  database column seller_biz_phone
     */
    private String sellerBizPhone;

    /**
     * remark:
     *   买家id
     *  corresponds  database column buyer_user_id
     */
    private String buyerUserId;

    /**
     * remark:
     *   买家业务联系电话
     *  corresponds  database column buyer_biz_phone
     */
    private String buyerBizPhone;

    /**
     * remark:
     *   优惠金额
     *  corresponds  database column discount
     */
    private Long discount;

    /**
     * remark:
     *   商品总金额
     *  corresponds  database column sum_product_payment
     */
    private Long sumProductPayment;

    /**
     * remark:
     *   应付总金额
     *  corresponds  database column sum_payment
     */
    private Long sumPayment;

    /**
     * remark:
     *   其他费用
     *  corresponds  database column additional_fee
     */
    private Long additionalFee;

    /**
     * remark:
     *   退款状态
     *  corresponds  database column refund_status
     */
    private Integer refundStatus;

    /**
     * remark:
     *   是否草拟订单
     *  corresponds  database column is_draft
     */
    private Integer isDraft;

    /**
     * remark:
     *   是否删除
     *  corresponds  database column is_delete
     */
    private Integer isDelete;

    /**
     * remark:
     *   订单确认时间
     *  corresponds  database column confirmed_time
     */
    private Date confirmedTime;

    /**
     * remark:
     *   确认有效时间
     *  corresponds  database column confirmed_valid_time
     */
    private Date confirmedValidTime;

    /**
     * remark:
     *   关闭类型 超时关闭 退款关闭 手工关闭
     *  corresponds  database column close_type
     */
    private Short closeType;

    /**
     * remark:
     *   关闭原因
     *  corresponds  database column close_reason
     */
    private String closeReason;

    /**
     * remark:
     *   订单主状态
     *  corresponds  database column status
     */
    private Integer status;

    /**
     * remark:
     *   备注
     *  corresponds  database column remark
     */
    private String remark;

    /**
     * remark:
     *   订单来源
     *  corresponds  database column source_id
     */
    private String sourceId;

    /**
     * remark:
     *   操作人
     *  corresponds  database column operator
     */
    private String operator;

    /**
     * remark:
     *   交易方式
     *  corresponds  database column trade_type
     */
    private Short tradeType;

    /**
     * remark:
     *   支付方式
     *  corresponds  database column pay_type
     */
    private String payType;

    /**
     * remark:
     *   交易关联id
     *  corresponds  database column order_group_id
     */
    private String orderGroupId;

    /**
     * remark:
     *   订单类型
     *  corresponds  database column order_type
     */
    private String orderType;

    /**
     * remark:
     *   阶段id（当前订单所处阶段）
     *  corresponds  database column stage_id
     */
    private String stageId;

    /**
     * remark:
     *   是否锁定
     *  corresponds  database column is_lock
     */
    private Integer isLock;

    /**
     * remark:
     *   交易关闭 成功等终态时间
     *  corresponds  database column end_time
     */
    private Date endTime;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo == null ? null : orderNo.trim();
    }

    public String getSellerUserId() {
        return sellerUserId;
    }

    public void setSellerUserId(String sellerUserId) {
        this.sellerUserId = sellerUserId == null ? null : sellerUserId.trim();
    }

    public String getSellerBizPhone() {
        return sellerBizPhone;
    }

    public void setSellerBizPhone(String sellerBizPhone) {
        this.sellerBizPhone = sellerBizPhone == null ? null : sellerBizPhone.trim();
    }

    public String getBuyerUserId() {
        return buyerUserId;
    }

    public void setBuyerUserId(String buyerUserId) {
        this.buyerUserId = buyerUserId == null ? null : buyerUserId.trim();
    }

    public String getBuyerBizPhone() {
        return buyerBizPhone;
    }

    public void setBuyerBizPhone(String buyerBizPhone) {
        this.buyerBizPhone = buyerBizPhone == null ? null : buyerBizPhone.trim();
    }

    public Long getDiscount() {
        return discount;
    }

    public void setDiscount(Long discount) {
        this.discount = discount;
    }

    public Long getSumProductPayment() {
        return sumProductPayment;
    }

    public void setSumProductPayment(Long sumProductPayment) {
        this.sumProductPayment = sumProductPayment;
    }

    public Long getSumPayment() {
        return sumPayment;
    }

    public void setSumPayment(Long sumPayment) {
        this.sumPayment = sumPayment;
    }

    public Long getAdditionalFee() {
        return additionalFee;
    }

    public void setAdditionalFee(Long additionalFee) {
        this.additionalFee = additionalFee;
    }

    public Integer getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(Integer refundStatus) {
        this.refundStatus = refundStatus;
    }

    public Integer getIsDraft() {
        return isDraft;
    }

    public void setIsDraft(Integer isDraft) {
        this.isDraft = isDraft;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public Date getConfirmedTime() {
        return confirmedTime;
    }

    public void setConfirmedTime(Date confirmedTime) {
        this.confirmedTime = confirmedTime;
    }

    public Date getConfirmedValidTime() {
        return confirmedValidTime;
    }

    public void setConfirmedValidTime(Date confirmedValidTime) {
        this.confirmedValidTime = confirmedValidTime;
    }

    public Short getCloseType() {
        return closeType;
    }

    public void setCloseType(Short closeType) {
        this.closeType = closeType;
    }

    public String getCloseReason() {
        return closeReason;
    }

    public void setCloseReason(String closeReason) {
        this.closeReason = closeReason == null ? null : closeReason.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId == null ? null : sourceId.trim();
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator == null ? null : operator.trim();
    }

    public Short getTradeType() {
        return tradeType;
    }

    public void setTradeType(Short tradeType) {
        this.tradeType = tradeType;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType == null ? null : payType.trim();
    }

    public String getOrderGroupId() {
        return orderGroupId;
    }

    public void setOrderGroupId(String orderGroupId) {
        this.orderGroupId = orderGroupId == null ? null : orderGroupId.trim();
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType == null ? null : orderType.trim();
    }

    public String getStageId() {
        return stageId;
    }

    public void setStageId(String stageId) {
        this.stageId = stageId == null ? null : stageId.trim();
    }

    public Integer getIsLock() {
        return isLock;
    }

    public void setIsLock(Integer isLock) {
        this.isLock = isLock;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}
