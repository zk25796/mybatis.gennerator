package com.wuage.order.dao;

import com.wuage.order.entity.OrderStage;
import com.wuage.order.entity.OrderStageExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderStageMapper {
    long countByExample(OrderStageExample example);

    int deleteByExample(OrderStageExample example);

    int deleteByPrimaryKey(Long id);

    int insert(OrderStage record);

    int insertSelective(OrderStage record);

    List<OrderStage> selectByExample(OrderStageExample example);

    OrderStage selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") OrderStage record, @Param("example") OrderStageExample example);

    int updateByExample(@Param("record") OrderStage record, @Param("example") OrderStageExample example);

    int updateByPrimaryKeySelective(OrderStage record);

    int updateByPrimaryKey(OrderStage record);
}