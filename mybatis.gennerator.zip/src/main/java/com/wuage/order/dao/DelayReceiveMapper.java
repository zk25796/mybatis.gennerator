package com.wuage.order.dao;

import com.wuage.order.entity.DelayReceive;
import com.wuage.order.entity.DelayReceiveExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DelayReceiveMapper {
    long countByExample(DelayReceiveExample example);

    int deleteByExample(DelayReceiveExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DelayReceive record);

    int insertSelective(DelayReceive record);

    List<DelayReceive> selectByExample(DelayReceiveExample example);

    DelayReceive selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DelayReceive record, @Param("example") DelayReceiveExample example);

    int updateByExample(@Param("record") DelayReceive record, @Param("example") DelayReceiveExample example);

    int updateByPrimaryKeySelective(DelayReceive record);

    int updateByPrimaryKey(DelayReceive record);
}