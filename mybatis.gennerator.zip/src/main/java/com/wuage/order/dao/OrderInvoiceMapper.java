package com.wuage.order.dao;

import com.wuage.order.entity.OrderInvoice;
import com.wuage.order.entity.OrderInvoiceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderInvoiceMapper {
    long countByExample(OrderInvoiceExample example);

    int deleteByExample(OrderInvoiceExample example);

    int deleteByPrimaryKey(Long id);

    int insert(OrderInvoice record);

    int insertSelective(OrderInvoice record);

    List<OrderInvoice> selectByExample(OrderInvoiceExample example);

    OrderInvoice selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") OrderInvoice record, @Param("example") OrderInvoiceExample example);

    int updateByExample(@Param("record") OrderInvoice record, @Param("example") OrderInvoiceExample example);

    int updateByPrimaryKeySelective(OrderInvoice record);

    int updateByPrimaryKey(OrderInvoice record);
}