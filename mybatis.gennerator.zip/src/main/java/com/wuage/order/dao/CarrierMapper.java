package com.wuage.order.dao;

import com.wuage.order.entity.Carrier;
import com.wuage.order.entity.CarrierExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CarrierMapper {
    long countByExample(CarrierExample example);

    int deleteByExample(CarrierExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Carrier record);

    int insertSelective(Carrier record);

    List<Carrier> selectByExample(CarrierExample example);

    Carrier selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Carrier record, @Param("example") CarrierExample example);

    int updateByExample(@Param("record") Carrier record, @Param("example") CarrierExample example);

    int updateByPrimaryKeySelective(Carrier record);

    int updateByPrimaryKey(Carrier record);
}