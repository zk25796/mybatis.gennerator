package com.wuage.order.dao;

import com.wuage.order.entity.OrderInvoiceDetail;
import com.wuage.order.entity.OrderInvoiceDetailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderInvoiceDetailMapper {
    long countByExample(OrderInvoiceDetailExample example);

    int deleteByExample(OrderInvoiceDetailExample example);

    int deleteByPrimaryKey(Long id);

    int insert(OrderInvoiceDetail record);

    int insertSelective(OrderInvoiceDetail record);

    List<OrderInvoiceDetail> selectByExample(OrderInvoiceDetailExample example);

    OrderInvoiceDetail selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") OrderInvoiceDetail record, @Param("example") OrderInvoiceDetailExample example);

    int updateByExample(@Param("record") OrderInvoiceDetail record, @Param("example") OrderInvoiceDetailExample example);

    int updateByPrimaryKeySelective(OrderInvoiceDetail record);

    int updateByPrimaryKey(OrderInvoiceDetail record);
}