package com.wuage.order.dao;

import com.wuage.order.entity.OrderGroup;
import com.wuage.order.entity.OrderGroupExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderGroupMapper {
    long countByExample(OrderGroupExample example);

    int deleteByExample(OrderGroupExample example);

    int deleteByPrimaryKey(Long id);

    int insert(OrderGroup record);

    int insertSelective(OrderGroup record);

    List<OrderGroup> selectByExample(OrderGroupExample example);

    OrderGroup selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") OrderGroup record, @Param("example") OrderGroupExample example);

    int updateByExample(@Param("record") OrderGroup record, @Param("example") OrderGroupExample example);

    int updateByPrimaryKeySelective(OrderGroup record);

    int updateByPrimaryKey(OrderGroup record);
}