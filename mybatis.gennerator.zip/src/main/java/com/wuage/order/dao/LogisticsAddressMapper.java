package com.wuage.order.dao;

import com.wuage.order.entity.LogisticsAddress;
import com.wuage.order.entity.LogisticsAddressExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LogisticsAddressMapper {
    long countByExample(LogisticsAddressExample example);

    int deleteByExample(LogisticsAddressExample example);

    int deleteByPrimaryKey(Long id);

    int insert(LogisticsAddress record);

    int insertSelective(LogisticsAddress record);

    List<LogisticsAddress> selectByExample(LogisticsAddressExample example);

    LogisticsAddress selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") LogisticsAddress record, @Param("example") LogisticsAddressExample example);

    int updateByExample(@Param("record") LogisticsAddress record, @Param("example") LogisticsAddressExample example);

    int updateByPrimaryKeySelective(LogisticsAddress record);

    int updateByPrimaryKey(LogisticsAddress record);
}