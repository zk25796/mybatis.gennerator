package com.wuage.order.dao;

import com.wuage.order.entity.OrderOffer;
import com.wuage.order.entity.OrderOfferExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderOfferMapper {
    long countByExample(OrderOfferExample example);

    int deleteByExample(OrderOfferExample example);

    int deleteByPrimaryKey(Long id);

    int insert(OrderOffer record);

    int insertSelective(OrderOffer record);

    List<OrderOffer> selectByExample(OrderOfferExample example);

    OrderOffer selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") OrderOffer record, @Param("example") OrderOfferExample example);

    int updateByExample(@Param("record") OrderOffer record, @Param("example") OrderOfferExample example);

    int updateByPrimaryKeySelective(OrderOffer record);

    int updateByPrimaryKey(OrderOffer record);
}