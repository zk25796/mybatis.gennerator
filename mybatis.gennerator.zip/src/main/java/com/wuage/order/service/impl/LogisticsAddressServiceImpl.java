package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.LogisticsAddressMapper;
import com.wuage.order.entity.LogisticsAddress;
import com.wuage.order.entity.LogisticsAddressExample;
import com.wuage.order.service.LogisticsAddressService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 收货地址操作服务,LogisticsAddressService实现类,
 */
@Service
public class LogisticsAddressServiceImpl implements LogisticsAddressService {

	@Autowired
	LogisticsAddressMapper logisticsAddressMapper;
	@Override
	public LogisticsAddress query(Long id) {
		return logisticsAddressMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<LogisticsAddress> queryList(LogisticsAddressExample example) {
		return logisticsAddressMapper.selectByExample(example);
	}

	@Override
	public int insert(LogisticsAddress record) {
		
		return logisticsAddressMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return logisticsAddressMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=logisticsAddressMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<LogisticsAddress> records) {
		int count=0;
		for (LogisticsAddress record : records) {
			count+=logisticsAddressMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(LogisticsAddress record) {
		return logisticsAddressMapper.updateByPrimaryKey(record);
	}

}
