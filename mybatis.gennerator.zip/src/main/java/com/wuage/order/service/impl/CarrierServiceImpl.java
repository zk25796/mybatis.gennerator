package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.CarrierMapper;
import com.wuage.order.entity.Carrier;
import com.wuage.order.entity.CarrierExample;
import com.wuage.order.service.CarrierService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 承运商服务,CarrierService实现类,
 */
@Service
public class CarrierServiceImpl implements CarrierService {

	@Autowired
	CarrierMapper carrierMapper;
	@Override
	public Carrier query(Long id) {
		return carrierMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Carrier> queryList(CarrierExample example) {
		return carrierMapper.selectByExample(example);
	}

	@Override
	public int insert(Carrier record) {
		
		return carrierMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return carrierMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=carrierMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<Carrier> records) {
		int count=0;
		for (Carrier record : records) {
			count+=carrierMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(Carrier record) {
		return carrierMapper.updateByPrimaryKey(record);
	}

}
