package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.DriverMapper;
import com.wuage.order.entity.Driver;
import com.wuage.order.entity.DriverExample;
import com.wuage.order.service.DriverService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 司机表服务,DriverService实现类,
 */
@Service
public class DriverServiceImpl implements DriverService {

	@Autowired
	DriverMapper driverMapper;
	@Override
	public Driver query(Long id) {
		return driverMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Driver> queryList(DriverExample example) {
		return driverMapper.selectByExample(example);
	}

	@Override
	public int insert(Driver record) {
		
		return driverMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return driverMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=driverMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<Driver> records) {
		int count=0;
		for (Driver record : records) {
			count+=driverMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(Driver record) {
		return driverMapper.updateByPrimaryKey(record);
	}

}
