package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.OrderOperationLogMapper;
import com.wuage.order.entity.OrderOperationLog;
import com.wuage.order.entity.OrderOperationLogExample;
import com.wuage.order.service.OrderOperationLogService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 订单日志服务,OrderOperationLogService实现类,
 */
@Service
public class OrderOperationLogServiceImpl implements OrderOperationLogService {

	@Autowired
	OrderOperationLogMapper orderOperationLogMapper;
	@Override
	public OrderOperationLog query(Long id) {
		return orderOperationLogMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<OrderOperationLog> queryList(OrderOperationLogExample example) {
		return orderOperationLogMapper.selectByExample(example);
	}

	@Override
	public int insert(OrderOperationLog record) {
		
		return orderOperationLogMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return orderOperationLogMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=orderOperationLogMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<OrderOperationLog> records) {
		int count=0;
		for (OrderOperationLog record : records) {
			count+=orderOperationLogMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(OrderOperationLog record) {
		return orderOperationLogMapper.updateByPrimaryKey(record);
	}

}
