package com.wuage.order.service;

import java.util.List;
import com.wuage.order.entity.LogisticsAddress;
import com.wuage.order.entity.LogisticsAddressExample;

/**
 * @author zhiyuan.wang create on @2017年06月09日 16时:19分
 * @desc 收货地址操作服务
 */
public interface LogisticsAddressService {
	
	/**
	 * @param id
	 * @return
	 */
	LogisticsAddress query(Long id);

	/**
	 * @param example
	 * @return
	 */
	List<LogisticsAddress> queryList(LogisticsAddressExample example);

	/**
	 * @param record
	 * @return
	 */
	int insert(LogisticsAddress record);

	/**
	 * @param id
	 * @return
	 */
	int delete(Long id);

	/**
	 * @param ids
	 * @return
	 */
	int delete(List<Long> ids);

	/**
	 * @param records
	 * @return
	 */
	int update(List<LogisticsAddress> records);

	/**
	 * @param record
	 * @return
	 */
	int update(LogisticsAddress record);
}
