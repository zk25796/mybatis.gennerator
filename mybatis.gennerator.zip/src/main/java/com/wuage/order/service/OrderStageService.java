package com.wuage.order.service;

import java.util.List;
import com.wuage.order.entity.OrderStage;
import com.wuage.order.entity.OrderStageExample;

/**
 * @author zhiyuan.wang create on @2017年06月09日 16时:19分
 * @desc 分阶段表服务
 */
public interface OrderStageService {
	
	/**
	 * @param id
	 * @return
	 */
	OrderStage query(Long id);

	/**
	 * @param example
	 * @return
	 */
	List<OrderStage> queryList(OrderStageExample example);

	/**
	 * @param record
	 * @return
	 */
	int insert(OrderStage record);

	/**
	 * @param id
	 * @return
	 */
	int delete(Long id);

	/**
	 * @param ids
	 * @return
	 */
	int delete(List<Long> ids);

	/**
	 * @param records
	 * @return
	 */
	int update(List<OrderStage> records);

	/**
	 * @param record
	 * @return
	 */
	int update(OrderStage record);
}
