package com.wuage.order.service;

import java.util.List;
import com.wuage.order.entity.DelayReceive;
import com.wuage.order.entity.DelayReceiveExample;

/**
 * @author zhiyuan.wang create on @2017年06月09日 16时:19分
 * @desc 延迟收货服务
 */
public interface DelayReceiveService {
	
	/**
	 * @param id
	 * @return
	 */
	DelayReceive query(Long id);

	/**
	 * @param example
	 * @return
	 */
	List<DelayReceive> queryList(DelayReceiveExample example);

	/**
	 * @param record
	 * @return
	 */
	int insert(DelayReceive record);

	/**
	 * @param id
	 * @return
	 */
	int delete(Long id);

	/**
	 * @param ids
	 * @return
	 */
	int delete(List<Long> ids);

	/**
	 * @param records
	 * @return
	 */
	int update(List<DelayReceive> records);

	/**
	 * @param record
	 * @return
	 */
	int update(DelayReceive record);
}
