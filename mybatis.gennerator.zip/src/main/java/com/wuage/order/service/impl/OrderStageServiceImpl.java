package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.OrderStageMapper;
import com.wuage.order.entity.OrderStage;
import com.wuage.order.entity.OrderStageExample;
import com.wuage.order.service.OrderStageService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 分阶段表服务,OrderStageService实现类,
 */
@Service
public class OrderStageServiceImpl implements OrderStageService {

	@Autowired
	OrderStageMapper orderStageMapper;
	@Override
	public OrderStage query(Long id) {
		return orderStageMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<OrderStage> queryList(OrderStageExample example) {
		return orderStageMapper.selectByExample(example);
	}

	@Override
	public int insert(OrderStage record) {
		
		return orderStageMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return orderStageMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=orderStageMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<OrderStage> records) {
		int count=0;
		for (OrderStage record : records) {
			count+=orderStageMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(OrderStage record) {
		return orderStageMapper.updateByPrimaryKey(record);
	}

}
