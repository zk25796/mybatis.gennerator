package com.wuage.order.service;

import java.util.List;
import com.wuage.order.entity.Attachment;
import com.wuage.order.entity.AttachmentExample;

/**
 * @author zhiyuan.wang create on @2017年06月09日 16时:19分
 * @desc 附件操作服务
 */
public interface AttachmentService {
	
	/**
	 * @param id
	 * @return
	 */
	Attachment query(Long id);

	/**
	 * @param example
	 * @return
	 */
	List<Attachment> queryList(AttachmentExample example);

	/**
	 * @param record
	 * @return
	 */
	int insert(Attachment record);

	/**
	 * @param id
	 * @return
	 */
	int delete(Long id);

	/**
	 * @param ids
	 * @return
	 */
	int delete(List<Long> ids);

	/**
	 * @param records
	 * @return
	 */
	int update(List<Attachment> records);

	/**
	 * @param record
	 * @return
	 */
	int update(Attachment record);
}
