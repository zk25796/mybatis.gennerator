package com.wuage.order.service;

import java.util.List;
import com.wuage.order.entity.OrderInvoice;
import com.wuage.order.entity.OrderInvoiceExample;

/**
 * @author zhiyuan.wang create on @2017年06月09日 16时:19分
 * @desc 发货单服务
 */
public interface OrderInvoiceService {
	
	/**
	 * @param id
	 * @return
	 */
	OrderInvoice query(Long id);

	/**
	 * @param example
	 * @return
	 */
	List<OrderInvoice> queryList(OrderInvoiceExample example);

	/**
	 * @param record
	 * @return
	 */
	int insert(OrderInvoice record);

	/**
	 * @param id
	 * @return
	 */
	int delete(Long id);

	/**
	 * @param ids
	 * @return
	 */
	int delete(List<Long> ids);

	/**
	 * @param records
	 * @return
	 */
	int update(List<OrderInvoice> records);

	/**
	 * @param record
	 * @return
	 */
	int update(OrderInvoice record);
}
