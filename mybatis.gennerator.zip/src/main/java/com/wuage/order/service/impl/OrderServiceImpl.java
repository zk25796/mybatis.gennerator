package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.OrderMapper;
import com.wuage.order.entity.Order;
import com.wuage.order.entity.OrderExample;
import com.wuage.order.service.OrderService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 订单操作服务,OrderService实现类,
 */
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderMapper orderMapper;
	@Override
	public Order query(Long id) {
		return orderMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Order> queryList(OrderExample example) {
		return orderMapper.selectByExample(example);
	}

	@Override
	public int insert(Order record) {
		
		return orderMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return orderMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=orderMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<Order> records) {
		int count=0;
		for (Order record : records) {
			count+=orderMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(Order record) {
		return orderMapper.updateByPrimaryKey(record);
	}

}
