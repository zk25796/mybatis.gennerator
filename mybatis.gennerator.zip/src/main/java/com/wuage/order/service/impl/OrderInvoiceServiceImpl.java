package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.OrderInvoiceMapper;
import com.wuage.order.entity.OrderInvoice;
import com.wuage.order.entity.OrderInvoiceExample;
import com.wuage.order.service.OrderInvoiceService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 发货单服务,OrderInvoiceService实现类,
 */
@Service
public class OrderInvoiceServiceImpl implements OrderInvoiceService {

	@Autowired
	OrderInvoiceMapper orderInvoiceMapper;
	@Override
	public OrderInvoice query(Long id) {
		return orderInvoiceMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<OrderInvoice> queryList(OrderInvoiceExample example) {
		return orderInvoiceMapper.selectByExample(example);
	}

	@Override
	public int insert(OrderInvoice record) {
		
		return orderInvoiceMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return orderInvoiceMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=orderInvoiceMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<OrderInvoice> records) {
		int count=0;
		for (OrderInvoice record : records) {
			count+=orderInvoiceMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(OrderInvoice record) {
		return orderInvoiceMapper.updateByPrimaryKey(record);
	}

}
