package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.DelayReceiveMapper;
import com.wuage.order.entity.DelayReceive;
import com.wuage.order.entity.DelayReceiveExample;
import com.wuage.order.service.DelayReceiveService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 延迟收货服务,DelayReceiveService实现类,
 */
@Service
public class DelayReceiveServiceImpl implements DelayReceiveService {

	@Autowired
	DelayReceiveMapper delayReceiveMapper;
	@Override
	public DelayReceive query(Long id) {
		return delayReceiveMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<DelayReceive> queryList(DelayReceiveExample example) {
		return delayReceiveMapper.selectByExample(example);
	}

	@Override
	public int insert(DelayReceive record) {
		
		return delayReceiveMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return delayReceiveMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=delayReceiveMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<DelayReceive> records) {
		int count=0;
		for (DelayReceive record : records) {
			count+=delayReceiveMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(DelayReceive record) {
		return delayReceiveMapper.updateByPrimaryKey(record);
	}

}
