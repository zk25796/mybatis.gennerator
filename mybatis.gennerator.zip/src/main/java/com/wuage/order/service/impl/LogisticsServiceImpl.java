package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.LogisticsMapper;
import com.wuage.order.entity.Logistics;
import com.wuage.order.entity.LogisticsExample;
import com.wuage.order.service.LogisticsService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 物流信息服务,LogisticsService实现类,
 */
@Service
public class LogisticsServiceImpl implements LogisticsService {

	@Autowired
	LogisticsMapper logisticsMapper;
	@Override
	public Logistics query(Long id) {
		return logisticsMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Logistics> queryList(LogisticsExample example) {
		return logisticsMapper.selectByExample(example);
	}

	@Override
	public int insert(Logistics record) {
		
		return logisticsMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return logisticsMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=logisticsMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<Logistics> records) {
		int count=0;
		for (Logistics record : records) {
			count+=logisticsMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(Logistics record) {
		return logisticsMapper.updateByPrimaryKey(record);
	}

}
