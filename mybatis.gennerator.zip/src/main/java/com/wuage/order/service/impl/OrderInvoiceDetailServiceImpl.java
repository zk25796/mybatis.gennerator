package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.OrderInvoiceDetailMapper;
import com.wuage.order.entity.OrderInvoiceDetail;
import com.wuage.order.entity.OrderInvoiceDetailExample;
import com.wuage.order.service.OrderInvoiceDetailService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 发货单明细服务,OrderInvoiceDetailService实现类,
 */
@Service
public class OrderInvoiceDetailServiceImpl implements OrderInvoiceDetailService {

	@Autowired
	OrderInvoiceDetailMapper orderInvoiceDetailMapper;
	@Override
	public OrderInvoiceDetail query(Long id) {
		return orderInvoiceDetailMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<OrderInvoiceDetail> queryList(OrderInvoiceDetailExample example) {
		return orderInvoiceDetailMapper.selectByExample(example);
	}

	@Override
	public int insert(OrderInvoiceDetail record) {
		
		return orderInvoiceDetailMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return orderInvoiceDetailMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=orderInvoiceDetailMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<OrderInvoiceDetail> records) {
		int count=0;
		for (OrderInvoiceDetail record : records) {
			count+=orderInvoiceDetailMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(OrderInvoiceDetail record) {
		return orderInvoiceDetailMapper.updateByPrimaryKey(record);
	}

}
