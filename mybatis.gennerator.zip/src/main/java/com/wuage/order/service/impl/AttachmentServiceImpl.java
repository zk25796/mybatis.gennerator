package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.AttachmentMapper;
import com.wuage.order.entity.Attachment;
import com.wuage.order.entity.AttachmentExample;
import com.wuage.order.service.AttachmentService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 附件操作服务,AttachmentService实现类,
 */
@Service
public class AttachmentServiceImpl implements AttachmentService {

	@Autowired
	AttachmentMapper attachmentMapper;
	@Override
	public Attachment query(Long id) {
		return attachmentMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<Attachment> queryList(AttachmentExample example) {
		return attachmentMapper.selectByExample(example);
	}

	@Override
	public int insert(Attachment record) {
		
		return attachmentMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return attachmentMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=attachmentMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<Attachment> records) {
		int count=0;
		for (Attachment record : records) {
			count+=attachmentMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(Attachment record) {
		return attachmentMapper.updateByPrimaryKey(record);
	}

}
