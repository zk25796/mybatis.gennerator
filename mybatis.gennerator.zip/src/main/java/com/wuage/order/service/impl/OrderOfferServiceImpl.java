package com.wuage.order.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wuage.order.dao.OrderOfferMapper;
import com.wuage.order.entity.OrderOffer;
import com.wuage.order.entity.OrderOfferExample;
import com.wuage.order.service.OrderOfferService;
/**
 * @author zhiyuan.wang
 * create on 2017年06月09日 16时:19分
 * 商品明细操作服务,OrderOfferService实现类,
 */
@Service
public class OrderOfferServiceImpl implements OrderOfferService {

	@Autowired
	OrderOfferMapper orderOfferMapper;
	@Override
	public OrderOffer query(Long id) {
		return orderOfferMapper.selectByPrimaryKey(id);
	}

	@Override
	public List<OrderOffer> queryList(OrderOfferExample example) {
		return orderOfferMapper.selectByExample(example);
	}

	@Override
	public int insert(OrderOffer record) {
		
		return orderOfferMapper.insertSelective(record);
	}

	@Override
	public int delete(Long id) {
		return orderOfferMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int delete(List<Long> ids) {
		int count=0;
		for (Long id : ids) {
			count+=orderOfferMapper.deleteByPrimaryKey(id);
		}
		return count;
	}

	@Override
	public int update(List<OrderOffer> records) {
		int count=0;
		for (OrderOffer record : records) {
			count+=orderOfferMapper.updateByPrimaryKey(record);
		}
		return count;
	}
	@Override
	public int update(OrderOffer record) {
		return orderOfferMapper.updateByPrimaryKey(record);
	}

}
