package com.wuage.order.entity;

import java.util.Date;

/**
 * Entity Remarks:
 *   分阶段记录表
 * This class corresponds to the database table tc_order_stage
 */
public class OrderStage {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   阶段编码（阶段1、2、3）
     *  corresponds  database column stage_seq
     */
    private String stageSeq;

    /**
     * remark:
     *   应付总金额
     *  corresponds  database column sum_money
     */
    private Long sumMoney;

    /**
     * remark:
     *   支付时间
     *  corresponds  database column pay_time
     */
    private Date payTime;

    /**
     * remark:
     *   支付截止时间
     *  corresponds  database column pay_timeout
     */
    private Date payTimeout;

    /**
     * remark:
     *   发货时间
     *  corresponds  database column send_time
     */
    private Date sendTime;

    /**
     * remark:
     *   实际收货时间
     *  corresponds  database column receive_time
     */
    private Date receiveTime;

    /**
     * remark:
     *   收货截止时间
     *  corresponds  database column receive_timeout
     */
    private Date receiveTimeout;

    /**
     * remark:
     *   延期收货时间
     *  corresponds  database column delay_receive_timeout
     */
    private Date delayReceiveTimeout;

    /**
     * remark:
     *   订单
     *  corresponds  database column order_id
     */
    private Long orderId;

    /**
     * remark:
     *   已发货 已收货  已付款 已完成
     *  corresponds  database column status
     */
    private Short status;

    /**
     * remark:
     *   发货状态
     *  corresponds  database column send_status
     */
    private Integer sendStatus;

    /**
     * remark:
     *   收货状态
     *  corresponds  database column receive_status
     */
    private Integer receiveStatus;

    /**
     * remark:
     *   支付状态
     *  corresponds  database column payment_status
     */
    private Integer paymentStatus;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStageSeq() {
        return stageSeq;
    }

    public void setStageSeq(String stageSeq) {
        this.stageSeq = stageSeq == null ? null : stageSeq.trim();
    }

    public Long getSumMoney() {
        return sumMoney;
    }

    public void setSumMoney(Long sumMoney) {
        this.sumMoney = sumMoney;
    }

    public Date getPayTime() {
        return payTime;
    }

    public void setPayTime(Date payTime) {
        this.payTime = payTime;
    }

    public Date getPayTimeout() {
        return payTimeout;
    }

    public void setPayTimeout(Date payTimeout) {
        this.payTimeout = payTimeout;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    public Date getReceiveTimeout() {
        return receiveTimeout;
    }

    public void setReceiveTimeout(Date receiveTimeout) {
        this.receiveTimeout = receiveTimeout;
    }

    public Date getDelayReceiveTimeout() {
        return delayReceiveTimeout;
    }

    public void setDelayReceiveTimeout(Date delayReceiveTimeout) {
        this.delayReceiveTimeout = delayReceiveTimeout;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public Integer getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(Integer sendStatus) {
        this.sendStatus = sendStatus;
    }

    public Integer getReceiveStatus() {
        return receiveStatus;
    }

    public void setReceiveStatus(Integer receiveStatus) {
        this.receiveStatus = receiveStatus;
    }

    public Integer getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(Integer paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}