package com.wuage.order.entity;

import java.util.Date;

/**
 * Entity Remarks:
 *   司机表
 * This class corresponds to the database table tc_driver
 */
public class Driver {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   发货单id
     *  corresponds  database column invoice_id
     */
    private Long invoiceId;

    /**
     * remark:
     *   车牌号
     *  corresponds  database column plate_number
     */
    private Integer plateNumber;

    /**
     * remark:
     *   司机名字
     *  corresponds  database column driver_name
     */
    private String driverName;

    /**
     * remark:
     *   司机联系电话
     *  corresponds  database column driver_mobile
     */
    private String driverMobile;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Integer getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(Integer plateNumber) {
        this.plateNumber = plateNumber;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName == null ? null : driverName.trim();
    }

    public String getDriverMobile() {
        return driverMobile;
    }

    public void setDriverMobile(String driverMobile) {
        this.driverMobile = driverMobile == null ? null : driverMobile.trim();
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}