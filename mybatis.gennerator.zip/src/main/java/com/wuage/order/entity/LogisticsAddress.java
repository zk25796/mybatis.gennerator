package com.wuage.order.entity;

import java.util.Date;

/**
 * Entity Remarks:
 *   收货地址表
 * This class corresponds to the database table tc_logistics_address
 */
public class LogisticsAddress {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   物流信息id
     *  corresponds  database column logistics_id
     */
    private Long logisticsId;

    /**
     * remark:
     *   详细地址
     *  corresponds  database column address
     */
    private String address;

    /**
     * remark:
     *   区的6位编码
     *  corresponds  database column area_code
     */
    private String areaCode;

    /**
     * remark:
     *   地区名称
     *  corresponds  database column area_name
     */
    private String areaName;

    /**
     * remark:
     *   市的6位编码
     *  corresponds  database column city_code
     */
    private String cityCode;

    /**
     * remark:
     *   城市名称
     *  corresponds  database column city_name
     */
    private String cityName;

    /**
     * remark:
     *   省名称
     *  corresponds  database column province_name
     */
    private String provinceName;

    /**
     * remark:
     *   省code
     *  corresponds  database column province_code
     */
    private String provinceCode;

    /**
     * remark:
     *   邮编
     *  corresponds  database column post_code
     */
    private String postCode;

    /**
     * remark:
     *   仓库
     *  corresponds  database column warehouse
     */
    private String warehouse;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLogisticsId() {
        return logisticsId;
    }

    public void setLogisticsId(Long logisticsId) {
        this.logisticsId = logisticsId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode == null ? null : areaCode.trim();
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName == null ? null : areaName.trim();
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode == null ? null : cityCode.trim();
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName == null ? null : cityName.trim();
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName == null ? null : provinceName.trim();
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode == null ? null : provinceCode.trim();
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode == null ? null : postCode.trim();
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse == null ? null : warehouse.trim();
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}