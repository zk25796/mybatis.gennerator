package com.wuage.order.entity;

import java.util.Date;

/**
 * Entity Remarks:
 *   记录物流信息
 * This class corresponds to the database table tc_logistics
 */
public class Logistics {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   订单id
     *  corresponds  database column order_id
     */
    private Long orderId;

    /**
     * remark:
     *   阶段id
     *  corresponds  database column stage_id
     */
    private Long stageId;

    /**
     * remark:
     *   物流方式：自提承运
     *  corresponds  database column pick_type
     */
    private String pickType;

    /**
     * remark:
     *   到货截止日期
     *  corresponds  database column appointed_arrival_date
     */
    private Date appointedArrivalDate;

    /**
     * remark:
     *   联系人姓名
     *  corresponds  database column contact_name
     */
    private String contactName;

    /**
     * remark:
     *   联系人手机号码
     *  corresponds  database column contact_mobile
     */
    private String contactMobile;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public String getPickType() {
        return pickType;
    }

    public void setPickType(String pickType) {
        this.pickType = pickType == null ? null : pickType.trim();
    }

    public Date getAppointedArrivalDate() {
        return appointedArrivalDate;
    }

    public void setAppointedArrivalDate(Date appointedArrivalDate) {
        this.appointedArrivalDate = appointedArrivalDate;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName == null ? null : contactName.trim();
    }

    public String getContactMobile() {
        return contactMobile;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile == null ? null : contactMobile.trim();
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}