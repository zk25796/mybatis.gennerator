package com.wuage.order.entity;

import java.util.Date;

/**
 * Entity Remarks:
 *   发货单明细表
 * This class corresponds to the database table tc_order_invoice_detail
 */
public class OrderInvoiceDetail {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   发货单id
     *  corresponds  database column invoice_id
     */
    private Long invoiceId;

    /**
     * remark:
     *   订单商品明细id
     *  corresponds  database column order_offer_id
     */
    private Long orderOfferId;

    /**
     * remark:
     *   发货数量
     *  corresponds  database column send_quantity
     */
    private Long sendQuantity;

    /**
     * remark:
     *   收货数量
     *  corresponds  database column receive_quantity
     */
    private Long receiveQuantity;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create
     */
    private Date gmtCreate;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified
     */
    private Date gmtModified;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(Long invoiceId) {
        this.invoiceId = invoiceId;
    }

    public Long getOrderOfferId() {
        return orderOfferId;
    }

    public void setOrderOfferId(Long orderOfferId) {
        this.orderOfferId = orderOfferId;
    }

    public Long getSendQuantity() {
        return sendQuantity;
    }

    public void setSendQuantity(Long sendQuantity) {
        this.sendQuantity = sendQuantity;
    }

    public Long getReceiveQuantity() {
        return receiveQuantity;
    }

    public void setReceiveQuantity(Long receiveQuantity) {
        this.receiveQuantity = receiveQuantity;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
}