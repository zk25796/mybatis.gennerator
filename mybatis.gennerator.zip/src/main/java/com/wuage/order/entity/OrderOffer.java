package com.wuage.order.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Entity Remarks:
 *   商品明细表
 * This class corresponds to the database table tc_order_offer
 */
public class OrderOffer {
    /**
     *  corresponds  database column id
     */
    private Long id;

    /**
     * remark:
     *   offer_id
     *  corresponds  database column offer_id
     */
    private String offerId;

    /**
     * remark:
     *   SKU_id
     *  corresponds  database column sku_id
     */
    private String skuId;

    /**
     * remark:
     *   品名
     *  corresponds  database column product_name
     */
    private String productName;

    /**
     * remark:
     *   材质
     *  corresponds  database column material
     */
    private String material;

    /**
     * remark:
     *   规格
     *  corresponds  database column specification
     */
    private String specification;

    /**
     * remark:
     *   数量
     *  corresponds  database column quantity
     */
    private BigDecimal quantity;

    /**
     * remark:
     *   单位
     *  corresponds  database column unit
     */
    private String unit;

    /**
     * remark:
     *   单价
     *  corresponds  database column unit_price
     */
    private Long unitPrice;

    /**
     * remark:
     *   总价
     *  corresponds  database column total_price
     */
    private Long totalPrice;

    /**
     * remark:
     *   仓库
     *  corresponds  database column warehouse
     */
    private String warehouse;

    /**
     * remark:
     *   厂家
     *  corresponds  database column facturer
     */
    private String facturer;

    /**
     * remark:
     *   实际发货数量
     *  corresponds  database column send_num
     */
    private Long sendNum;

    /**
     * remark:
     *   实际收到货物数量
     *  corresponds  database column received_num
     */
    private Long receivedNum;

    /**
     * remark:
     *   订单id
     *  corresponds  database column order_id
     */
    private Long orderId;

    /**
     * remark:
     *   创建时间
     *  corresponds  database column gmt_create2
     */
    private Date gmtCreate2;

    /**
     * remark:
     *   修改时间
     *  corresponds  database column gmt_modified2
     */
    private Date gmtModified2;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId == null ? null : offerId.trim();
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId == null ? null : skuId.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material == null ? null : material.trim();
    }

    public String getSpecification() {
        return specification;
    }

    public void setSpecification(String specification) {
        this.specification = specification == null ? null : specification.trim();
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {
        this.quantity = quantity;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit == null ? null : unit.trim();
    }

    public Long getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Long unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Long getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Long totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(String warehouse) {
        this.warehouse = warehouse == null ? null : warehouse.trim();
    }

    public String getFacturer() {
        return facturer;
    }

    public void setFacturer(String facturer) {
        this.facturer = facturer == null ? null : facturer.trim();
    }

    public Long getSendNum() {
        return sendNum;
    }

    public void setSendNum(Long sendNum) {
        this.sendNum = sendNum;
    }

    public Long getReceivedNum() {
        return receivedNum;
    }

    public void setReceivedNum(Long receivedNum) {
        this.receivedNum = receivedNum;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Date getGmtCreate2() {
        return gmtCreate2;
    }

    public void setGmtCreate2(Date gmtCreate2) {
        this.gmtCreate2 = gmtCreate2;
    }

    public Date getGmtModified2() {
        return gmtModified2;
    }

    public void setGmtModified2(Date gmtModified2) {
        this.gmtModified2 = gmtModified2;
    }
}